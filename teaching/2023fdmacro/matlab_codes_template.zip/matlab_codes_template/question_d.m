% I intentionally added quite a few mistakes 
% into this file, to make sure that nobody can just copy 
% all the codes to her software and get correct results.

% first repeat (b)
% define the parameters,here a denotes alpha,b denotes beta%


clear all;clc;close all;
a=0.2;b=0.99;A=2; epsilon=0.0001;
c=log(A*(1-a*b))/(1-b)+a*b*log(A*a*b)/((1-a*b)*(1-b)) ; 
d=a/(1-a*b); m=b*d*A/(1+b*d);kss=m^(1/(1-a));
k0=linspace(0.1*kss,1.9*kss,1000);
% begin the iteration process
v0=k0-k0;v1=v0+1;
for i=1:1000;
v=log(2*k0(i)^0.2-k0)+b*v1;
[value,ma]=max(v);
k1(i)=k0(ma);
v1(i)=value;
end

while max(abs(v1-v0))>=epsilon
  v0=v1 ;   
  for i=1:1000
v=log(A*k0(i)^a-k0)+b*v0;
[value,ma]=max(v);
k1(i)=k0(ma);
v0(i)=value; 
   end
end

% begin the iteration with new function

v2=k0-k0;v3=v2+1;
for i=1:1000;
v=((2*k0(i)^0.2-k1).^0.5-1)*2+b*v2;
[value,ma]=max(v);
k1(i)=k0(ma);
v2(i)=value;
end

while max(abs(v1-v0))>=epsilon
  v2=v3 ;   
  for i=1:1000
v=((2*k0(i)^0.2-k1).^0.5-1)*2+b*v2;
[value,ma]=max(v);
k2(i)=k0(ma);
v2(i)=value; 
   end
end

figure1=figure;
plot(k0,v1,'-k')
hold
plot(k0,v2,'-r')
legend('Location','southeast','value function for u(c_t)=log(c_t)','value function for u(c_t)=(c_t^{0.5}-1)/0.5')


figure2=figure;
plot(k0,k1,'-k')
hold
plot(k0,k2,'-r')
legend('Location','southeast','policy function for u(c_t)=log(c_t)','policy function for u(c_t)=(c_t^{0.5}-1)/0.5')


