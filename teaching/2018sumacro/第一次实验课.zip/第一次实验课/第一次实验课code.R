#创建向量
v1<-5:10
v2<-1.5:4.5
v3<-seq(5,11,by=0.5)
v4<-c("TURE", TRUE, 3)
#访问向量元素
v1[3]
v2[c(3,4)]
v1+v2

#创建列表
mylist <- list("Red", "Green", c(21,32,11), TRUE, 51.23, 119.1)
list1 <- list(1,2,3)
list2 <- list("Sun","Mon","Tue")
#命名列表
names(mylist) <- c("1st","Quarter", "A_vector", "AInnerlist")
#访问列表元素
mylist[1]
mylist$A_Matrix
#合并列表
newlist<-c(list1,list2)
newlist

#创建矩阵
mymatrix<- matrix(c(1:16), nrow = 4, byrow = TRUE)
matrix1<-cbind(v1,v3)
matrix2<-rbind(v1,v3)
mymatrix
matrix1
matrix2
#给矩阵行列命名
rownames(mymatrix) = c("row1", "row2", "row3", "row4")
colnames(mymatrix) = c("col1", "col2", "col3","col4")
#访问矩阵元素
mymatrix[3,4]
mymatrix[3, ]
mymatrix[ ,4]

#创建数组
myarray<-array(1:10, dim = c(3,3,2))
#命名数组
dimnames(myarray)<-list(c("ROW1","ROW2","ROW3"), c("COL1","COL2","COL3"), 
                        c("Matrix1","Matrix2"))
#数组元素的访问
myarray[2,2,2]
myarray[2, , ]

#创建一个因子
myfactor <- factor(c("East","West","East","North","North",
                        "East","West","West","West","East","North"))
myfactor

#创建一个数据框
mydata.frame<-data.frame(c("liu","wang","zhang"), 
                         c("U432","U456","U674"),c(95, 98, 92))
mydata.frame
#命名数据框的列
names(mydata.frame)<-c("name", "numbers", "grade")
#添加列
mydata.frame$rank<-c(2, 1, 3)
#添加行
newrow<-data.frame(name="zhao", numbers="U345", grade=90, rank=4)
mydata.frame<-rbind(mydata.frame, newrow)
mydata.frame
#访问数据框的元素
mydata.frame[,3]
mydata.frame$grade

#数据的导入
data1<-read.table("E:\\资料\\高宏助教\\R语言实验课\\input.txt", header=T, na.strings=".")
data2<-read.csv("E:\\资料\\高宏助教\\R语言实验课\\input.csv")
install.packages("xlsx")
library(xlsx)
data3<-read.xlsx("E:\\资料\\高宏助教\\R语言实验课\\input.xlsx",sheetIndex = 1)

#数据处理
#查看描述性统计
summary(data3)
summary(data3$salary)
#求和
sum(data1$id, na.rm = T)
#替代
data1$salary<-replace(data1$salary, data1$salary>700, 1000)
#选取
subset(data2,salary==623.3)
#排序
data1[order(data1$salary),]
#分类汇总
aggregate(data1$salary,by=list(data1$dept),mean)

#数据导出
write.csv(data3,file = "E:\\资料\\高宏助教\\R语言实验课\\output.csv")
write.xlsx(data3,file = "E:\\资料\\高宏助教\\R语言实验课\\output.xlsx")
