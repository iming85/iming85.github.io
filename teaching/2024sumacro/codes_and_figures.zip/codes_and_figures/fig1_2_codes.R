
## Version: April 2020

## a Numerical Example for (5.42) in D. Romer's Advanced Macroeconomics Textbook (4th edition)

library(mFilter)

a=2/3
rhoA=1/3
Abar=1
g=0.03
b=1/2
n=0.01
rho=0.1
Nbar=10
K0=10
stilde=a*exp(n-rho);ltilde=(1-a)/((1-a)+b*(1-stilde))
T=100
var=0.05


epsilon<- rnorm(T,0,var)
Ytilde<-0;Ytrend<-0;Y<-0
Ytilde[1]=(1-a)*epsilon[1]
Ytrend[1]=a*log(K0)+(1-a)*(Abar+log(ltilde)+Nbar)
Y[1]=Ytrend[1]+Ytilde[1]

Ytilde[2]=(1-a)*epsilon[2]+(a+rhoA)*Ytilde[1]
Ytrend[2]=a*log(stilde)+a*Ytrend[1]+(1-a)*(Abar+g*1+log(ltilde)+Nbar+n)
Y[2]=Ytrend[2]+Ytilde[2]

for (t in 3:T){
  Ytilde[t]=(a+rhoA)*Ytilde[t-1]-a*rhoA*Ytilde[t-2]+(1-a)*epsilon[t]
  Ytrend[t]=a*log(stilde)+a*Ytrend[1]+(1-a)*(Abar+g*(t-1)+log(ltilde)+Nbar+n*(t-1))
  Y[t]=Ytilde[t]+Ytrend[t]
}

Y = Y[c(-1,-2)]
Ytrend = Ytrend[c(-1,-2)]
Ytilde = Ytilde[c(-1,-2)]
## Now detrend the data using Hodrick-Prescott filter, treat data as queterly, so lambda=1600.a
## You should have library mFilter installed in advance.
filterY = hpfilter(Y,freq=1600)
hp_trendY = filterY$trend
hp_cycleY = filterY$cycle

T1 = T-2

# figure 1a
plot(1:T1,Y,xlab="Quarter",ylab="log value","l",lwd=2)
lines(1:T1,Ytrend, col="red",lwd=2,lty=5)
legend("topleft",bty="n",y.intersp=1.4,legend=c(expression(lnY(t)),   
                                                expression(paste(lnY^trend,"(t)")) ),
       lty=c(1,5),lwd=rep(2,1),
       col=c("black","red"))

## figure 1b
plot(1:T1,Y,xlab="Quarter",ylab="log value","l",lwd=2)
lines(1:T1,hp_trendY, col="red",lwd=2,lty=5)
legend("topleft",bty="n",y.intersp=1.4,legend=c(expression( lnY(t)      ),   
                                                expression(   paste("HP-filtered  ", lnY^trend,"(t)"   )    )),
       lty=c(1,5),lwd=rep(2,1),
       col=c("black","red"))


## figure 2a
plot(1:T1, 100*Ytilde, col="blue","l",xlab="Quarter",ylab="Percentage",lwd=2)
abline(h=0, col="darkcyan",lty=5,lwd=2)
legend("topleft",bty="n",legend=(expression(tilde(Y)(t))),lty=1,lwd=2,col=c("blue"))



## figure 2b
plot(1:T1, 100*Ytilde, col="blue","l",xlab="Quarter",ylab="Percentage",lwd=2)
lines(1:T1,100*hp_cycleY, col="red",lwd=2,lty=5)
abline(h=0, col="darkcyan",lty=5,lwd=1)
legend("topleft",bty="n",legend=c(expression(tilde(Y)(t)),
                                 expression( paste("HP-filtered  ", tilde(Y)(t)  ))),
       lty=c(1,5),lwd=c(2,2),col=c("blue","red"))











