
## Version: April 2020

## For (5.54) in Romer's textbook (4th edition). 
## This is, of course, an informal and incorrect study because I am
## fitting data by treating randomly generated paths of stochastics, 
## rather than observed ones, as the underlying realized shocks. 
## The codes below, however, can serve as a simple illustrating example. 

ala=0.35;alk=-0.31;aca=0.38;ack=0.59;bka=0.08;bkk=0.95;acg=-0.13;alg=0.15;bkg=-0.004
bkg=0.95*0.4+0.6*bkg
a=2/3;g=0.02;n=0.0025;delta=0.025;rhoa=0.95;rhog=0.94;r=0.015;l=1/3;vara<-0.001;varg<-0.001

chinadata <- read.csv("data.csv",header= FALSE);
chinadata <- chinadata/100
gyall<-chinadata[,2]
dummy<- gyall
for (i in 1:length(dummy)){
  gyall[i]<- dummy[length(dummy)-i+1]
}

#fundamental<-mean(gyall)
gyselect<-gyall[(length(gyall)-39):length(gyall)]
fundamental<- mean(gyselect)
ytilde<-gyselect-fundamental
ytilde[1]<-ytilde[1]+gyall[(length(gyall)-40)]-fundamental
ytilde[1]=ytilde[1]*13
for (i in 2:length(ytilde)){
  ytilde[i]<- ytilde[i]+ytilde[i-1]
}

ytilde<- ytilde/4

ktilde<-0;atilde<-0;gtilde<-0;ytilde_1<-0
epsilona<-rnorm(40,0,vara)
epsilong<-rnorm(40,0,varg)
scale<- a+(1-a)*alk+(1-a)*(1+ala)+(1-a)*alg
atilde[1]<- 0.9*ytilde[1]/scale
gtilde[1]<- ytilde[1]/scale
ktilde[1]<- ytilde[1]/scale
ytilde_1[1]<-(a+(1-a)*alk)*ktilde[1]+(1-a)*(1+ala)*atilde[1]+(1-a)*alg*gtilde[1]

for(i in 2:40){
  atilde[i]=rhoa*atilde[i-1]+epsilona[i]
  gtilde[i]=rhog*gtilde[i-1]+epsilong[i]
  ktilde[i]<- bkk*ktilde[i-1]+bka*atilde[i-1]+bkg*gtilde[i-1]
  ytilde_1[i]<-(a+(1-a)*alk)*ktilde[i]+(1-a)*(1+ala)*atilde[i]+(1-a)*alg*gtilde[i]
}



### Now consider the 2008 Financial crisis
epsilona[15]=abs(atilde[14])*(-0.5)
epsilona[16]=abs(atilde[14])*(-0.5)
epsilona[17]=abs(atilde[14])*(-0.5)
epsilona[18]=abs(atilde[14])*(-0.5)


ytilde_2<-0
ytilde_2[1]<-(a+(1-a)*alk)*ktilde[1]+(1-a)*(1+ala)*atilde[1]+(1-a)*alg*gtilde[1]
for(i in 2:40){
  atilde[i]=rhoa*atilde[i-1]+epsilona[i]
  gtilde[i]=rhog*gtilde[i-1]+epsilong[i]
  ktilde[i]<- bkk*ktilde[i-1]+bka*atilde[i-1]+bkg*gtilde[i-1]
  ytilde_2[i]<-(a+(1-a)*alk)*ktilde[i]+(1-a)*(1+ala)*atilde[i]+(1-a)*alg*gtilde[i]
}

### Now Further consider the 4 trillion investments in 2008/2009.
epsilong[15]=abs(gtilde[14])*0.5
epsilong[16]=abs(gtilde[14])*0.3



ytilde_3<-0
ytilde_3[1]<-(a+(1-a)*alk)*ktilde[1]+(1-a)*(1+ala)*atilde[1]+(1-a)*alg*gtilde[1]
for(i in 2:40){
  atilde[i]=rhoa*atilde[i-1]+epsilona[i]
  gtilde[i]=rhog*gtilde[i-1]+epsilong[i]
  ktilde[i]<- bkk*ktilde[i-1]+bka*atilde[i-1]+bkg*gtilde[i-1]
  ytilde_3[i]<-(a+(1-a)*alk)*ktilde[i]+(1-a)*(1+ala)*atilde[i]+(1-a)*alg*gtilde[i]
}

T=40
plot(1:T,100*ytilde,xlab="Number of Quarter starting from 2005:Q2",ylab="Percentage","l",ylim=c(100*min(ytilde)*0.9,100*max(ytilde)*1.1),lwd=2,lty=1)
lines(1:T,100*ytilde_1, col="darkcyan",lwd=2,type="b",pch=16)
lines(1:T,100*ytilde_2,col="blue",lwd=2,type="b",pch=17)
lines(1:T,100*ytilde_3,col="red",lwd=2,type="b",pch=15)
legend("topleft",bty="n",y.intersp=1.4,legend=c(expression(paste(tilde(Y),"(t)")),  
                                                expression(paste(tilde(Y)^1,"(t)")),
                                                expression(paste(tilde(Y)^2,"(t)")),
                                                expression(paste(tilde(Y)^3,"(t)")) ),
       pch=c(-1,16,17,15),lty=c(1,2,2,2),lwd=c(2,2,2,2),col=c("black","darkcyan","blue","red"))








