
## Version: April 2020

## Let us first calibrate parameters and figure out values of all the coefficients.

alpha = 1/3
g = 0.5/100
n = 0.25/100
delta = 2.5/100
rhoa = 0.95
rhog = 0.95
phi = 0.2
rho = 1/100
ell = 1/3
# calibrate the value of b such that ell=1/3
para1 = (1-phi)/(1-alpha); para2 = alpha*(n+g+delta)/( (1-alpha)*(g+rho+delta)  )
b=(1/ell -1)/(para1-para2)
##

# Now define all the lambda's

lam1 = alpha
lam2 = 1-alpha
lam3 = -( alpha+ell/(1-ell) )
lam4 = (1+g+rho)/(1+n+g)
lam5 = (1-alpha)*(g+rho+delta)/( alpha*(1+n+g) )
lam6 = (alpha*(n+g+delta) + (phi-1)*(g+rho+delta) )/( alpha*(1+n+g) )
lam7 = - phi*(g+rho+delta)/( alpha*(1+n+g) )
lam8 = (1-alpha)*(g+rho+delta)/( alpha*(1+n+g) )
lam9 = (g+rho+delta)*(1-alpha)/(1+g+rho)

###

q0 = lam4 +lam1*lam6
q1 = lam3*lam6 +lam8
q2 = q1*(lam3-lam9)
q3 = (lam3-lam9)*q0 + (lam1+lam9)*q1 -lam3
q4 = (lam1+lam9)*q0 -lam1

alk1 = (-q3 +sqrt(q3^2-4*q2*q4) )/(2*q2)
ack1 = lam1 + lam3*alk1
bkk1 = q0 + q1*alk1

alk2 = (-q3 -sqrt(q3^2-4*q2*q4) )/(2*q2)
ack2 = lam1 + lam3*alk2
bkk2 = q0 + q1*alk2

isTRUE(bkk1>1);isTRUE(bkk2>1)

alk=alk1; ack=ack1; bkk=bkk1;

ala= -((ack-lam9*(alk-1))*(lam5+lam2*lam6)+(rhoa-1)*lam2-lam9*rhoa)/
      ((ack-lam9*(alk-1))*(lam3*lam6+lam8) +(rhoa-1)*lam3-lam9*rhoa)

aca=lam2 +lam3 * ala
bka=lam5+lam2*lam6+(lam3*lam6+lam8)*ala


alg = -((ack-lam9*(alk-1))*lam7)/
       ((ack-lam9*(alk-1))*(lam3*lam6+lam8)+lam3*(rhog-1)-lam9*rhog)
acg = lam3*alg
bkg = lam7+ (lam3*lam6+lam8)*alg

## list their values
alk; ack;bkk;ala;aca;bka;alg;acg;bkg


####  Now let us consider the pure effects of a 1% technology shock at time 1, 
####  and replicate Fitures 5.2, 5.3, and 5.4.

atilde=ctilde=ltilde=ktilde=ytilde=rchange=wtilde=0;
initial_shock = 1
time_length=40

#for time 1
atilde[1] = initial_shock
ctilde[1] = aca*initial_shock
ltilde[1] = ala*initial_shock
ktilde[1] = 0
ytilde[1] = (alpha +(1-alpha)*alk)*ktilde[1] +(1-alpha)*(1+ala)*atilde[1]
rchange[1] = lam9*(atilde[1]+ltilde[1]-ktilde[1])*4
wtilde[1] = ytilde[1] - ltilde[1]


#for time 2
atilde[2] = rhoa*initial_shock
ctilde[2] = (bkk+rhoa)*ctilde[1]+(bka*ack-aca*bkk)*initial_shock
ltilde[2] = (bkk+rhoa)*ltilde[1]+(bka*alk-ala*bkk)*initial_shock
ktilde[2] = bka*initial_shock
ytilde[2] = (alpha +(1-alpha)*alk)*ktilde[2] +(1-alpha)*(1+ala)*atilde[2]
rchange[2] = lam9*(atilde[2]+ltilde[2]-ktilde[2])*4
wtilde[2] = ytilde[2] - ltilde[2]

# for t>2

for (i in 3:time_length){
  atilde[i] = rhoa^(i-1) * initial_shock
  ctilde[i] = (bkk+rhoa)*ctilde[i-1]-bkk*rhoa*ctilde[i-2]
  ltilde[i] = (bkk+rhoa)*ltilde[i-1]-bkk*rhoa*ltilde[i-2]
  ktilde[i] = (bkk+rhoa)*ktilde[i-1]-bkk*rhoa*ktilde[i-2]
  ytilde[i] = (alpha +(1-alpha)*alk)*ktilde[i] +(1-alpha)*(1+ala)*atilde[i]
  rchange[i] = lam9*(atilde[i]+ltilde[i]-ktilde[i])*4
  wtilde[i] = ytilde[i] - ltilde[i]
}


## replicate Figure 5.2
T=time_length
plot(1:T,atilde,xlab="Quarters",ylab="Percentage",col="red","l",xlim=c(1.6,40),ylim=c(-0.2,1),lwd=2)
axis(side=1, at=c(1:20)*2, labels=c(1:20)*2)
axis(side=1, at=1, labels=1)
abline(h=0, col="darkcyan")
lines(1:T,ktilde,col="blue",lwd=2,lty=5)
lines(1:T,ltilde,col="black",lwd=2,lty=4)
legend("top",bty="n",y.intersp=1.4,legend=c(expression(paste(tilde(A),"(t)")),
            expression(paste(tilde(K),"(t)")),
            expression(paste(tilde(L),"(t)")) ),
       lty=c(1,5,4),lwd=rep(2,2,2),col=c("red","blue","black"))



## replicate Figure 5.3

plot(1:T,ytilde,xlab="Quarters",ylab="Percentage", col="red", "l",xlim=c(1.6,40),ylim=c(-0.2,1),lwd=2)
axis(side=1, at=c(1:20)*2, labels=c(1:20)*2)
axis(side=1, at=1, labels=1)

abline(h=0, col="darkcyan")
lines(1:T,ctilde,col="blue",lwd=2,lty=5)
legend("top",bty="n",y.intersp=1.4,legend=c(expression(paste(tilde(Y),"(t)")),
                                                 expression(paste(tilde(C),"(t)"))),
       lty=c(1,5),lwd=rep(2,2),col=c("red","blue"))



## replicate Figure 5.4

plot(1:T,wtilde,xlab="Quarters",ylab="Percentage", col="red", "l",lty=1,xlim=c(1.6,40),ylim=c(-0.2,1),lwd=2)
axis(side=1, at=c(1:20)*2, labels=c(1:20)*2)
axis(side=1, at=1, labels=1)

abline(h=0, col="darkcyan")
lines(1:T,rchange,col="blue",lwd=2,lty=5)
legend("top",bty="n",y.intersp=1.4,legend=c(expression(paste(tilde(w),"(t)")),
                                                 expression(paste("annual ","r(t)-r*"))),
       lty=c(1,5),lwd=rep(2,2),col=c("red","blue"))
