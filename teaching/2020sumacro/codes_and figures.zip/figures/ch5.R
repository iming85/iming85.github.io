## Numerical Examples for (5.42) in D. Romer's Advanced Macroeconomics Textbook (4th edition)

a=1/3
rhoA=1/3
Abar=10
g=5
b=1/2
n=0.2
rho=0.1
Nbar=10
K0=10
stilde=a*exp(n-rho);ltilde=(1-a)/((1-a)+b*(1-stilde))
T=50
var=10


epsilon<- rnorm(T,0,var)
Ytilde<-0;Ytrend<-0;Y<-0
Ytilde[1]=(1-a)*epsilon[1]
Ytrend[1]=a*log(K0)+(1-a)*(Abar+log(ltilde)+Nbar)
Y[1]=Ytrend[1]+Ytilde[1]

Ytilde[2]=(1-a)*epsilon[2]+(a+rhoA)*Ytilde[1]
Ytrend[2]=a*log(stilde)+a*Ytrend[1]+(1-a)*(Abar+g*1+log(ltilde)+Nbar+n)
Y[2]=Ytrend[2]+Ytilde[2]

for (t in 3:T){
Ytilde[t]=(a+rhoA)*Ytilde[t-1]-a*rhoA*Ytilde[t-2]+(1-a)*epsilon[t]
Ytrend[t]=a*log(stilde)+a*Ytrend[1]+(1-a)*(Abar+g*(t-1)+log(ltilde)+Nbar+n*(t-1))
Y[t]=Ytilde[t]+Ytrend[t]
}


plot(1:T,Y,xlab="t",ylab="","l")
lines(1:T,Ytrend, col="red")
legend("topleft",bty="n",y.intersp=1.4,legend=c(expression(Y(t)),   expression(paste(Y^trend,"(t)")) ),lty=c(1,1),lwd=rep(2,2),col=c("black","red"))


plot(1:T, Ytilde, col="blue","l",xlab="t",ylab="")
legend("topleft",bty="n",legend=(expression(tilde(Y)(t))),lty=c(1,1),lwd=rep(2,2),col=c("blue"))







## Now for (5.54)
ala=0.35;alk=-0.31;aca=0.38;ack=0.59;bka=0.08;bkk=0.95;acg=-0.13;alg=0.15;bkg=-0.004
bkg=0.95*0.4+0.6*bkg
a=1/3;g=0.005;n=0.0025;delta=0.025;rhoa=0.95;rhog=0.95;r=0.015;l=1/3;

chinadata <- read.csv("data.csv",header= FALSE);
gyall<-chinadata[,2]
dummy<- gyall
for (i in 1:length(dummy)){
gyall[i]<- dummy[length(dummy)-i+1]
}

fundamental<-mean(gyall)
gyselect<-gyall[(length(gyall)-39):length(gyall)]
ytilde<-gyselect-fundamental

ktilde<-0;atilde<-0;gtilde<-0;ytilde_1<-0
vara=1;varg<-1
epsilona<-rnorm(40,0,vara)
epsilong<-rnorm(40,0,varg)
atilde[1]<-epsilona[1]
gtilde[1]<- epsilong[1]
ktilde[1]<-0
ytilde_1[1]<-(a+(1-a)*alk)*ktilde[1]+(1-a)*(1+ala)*atilde[1]+(1-a)*alg*gtilde[1]

for(i in 2:40){
  atilde[i]=rhoa*atilde[i-1]+epsilona[i]
  gtilde[i]=rhog*gtilde[i-1]+epsilong[i]
  ktilde[i]<- bkk*ktilde[i-1]+bka*atilde[i-1]+bkg*gtilde[i-1]
  ytilde_1[i]<-(a+(1-a)*alk)*ktilde[i]+(1-a)*(1+ala)*atilde[i]+(1-a)*alg*gtilde[i]
}

### Now consider the 2008 Financial crisis
epsilona[14]=abs(atilde[13])*(-1.8)
epsilona[15]=abs(atilde[15])*(-1.7)
epsilona[16]=abs(atilde[16])*(-1.6)
ytilde_2<-0
atilde[1]<-epsilona[1]
gtilde[1]<- epsilong[1]
ktilde[1]<-0
ytilde_2[1]<-(a+(1-a)*alk)*ktilde[1]+(1-a)*(1+ala)*atilde[1]+(1-a)*alg*gtilde[1]
for(i in 2:40){
  atilde[i]=rhoa*atilde[i-1]+epsilona[i]
  gtilde[i]=rhog*gtilde[i-1]+epsilong[i]
  ktilde[i]<- bkk*ktilde[i-1]+bka*atilde[i-1]+bkg*gtilde[i-1]
  ytilde_2[i]<-(a+(1-a)*alk)*ktilde[i]+(1-a)*(1+ala)*atilde[i]+(1-a)*alg*gtilde[i]
}

### Now Further consider the 4 trillion investments in 2009.
epsilong[16]=abs(gtilde[16])*1.5
epsilong[17]=abs(gtilde[17])*1.4
epsilong[18]=abs(gtilde[18])*1.3
epsilong[19]=abs(gtilde[19])*1.2

ytilde_3<-0
atilde[1]<-epsilona[1]
gtilde[1]<- epsilong[1]
ktilde[1]<-0
ytilde_3[1]<-(a+(1-a)*alk)*ktilde[1]+(1-a)*(1+ala)*atilde[1]+(1-a)*alg*gtilde[1]
for(i in 2:40){
  atilde[i]=rhoa*atilde[i-1]+epsilona[i]
  gtilde[i]=rhog*gtilde[i-1]+epsilong[i]
  ktilde[i]<- bkk*ktilde[i-1]+bka*atilde[i-1]+bkg*gtilde[i-1]
  ytilde_3[i]<-(a+(1-a)*alk)*ktilde[i]+(1-a)*(1+ala)*atilde[i]+(1-a)*alg*gtilde[i]
}

T=40
plot(1:T,ytilde,xlab="t",ylab="","l",ylim=c(-6,6))
lines(1:T,ytilde_1, col="red")
lines(1:T,ytilde_2,col="blue")
lines(1:T,ytilde_3,col="cyan")
legend("topleft",bty="n",y.intersp=1.4,legend=c(expression(paste(tilde(Y),"(t)")),   expression(paste(tilde(Y)^1,"(t)")),expression(paste(tilde(Y)^2,"(t)")),expression(paste(tilde(Y)^3,"(t)")) ),lty=c(1,1),lwd=rep(2,2),col=c("black","red","blue","cyan"))








